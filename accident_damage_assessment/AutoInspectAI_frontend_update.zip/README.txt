AutoInspect AI frontend update

Copy these four files into your project, replacing the existing files:

1. index.html -> accident_damage_assessment\templates\index.html
2. style.css -> accident_damage_assessment\static\style.css
3. app.js -> accident_damage_assessment\static\app.js
4. region-report.js -> accident_damage_assessment\static\region-report.js

No backend/P1-P4 files are changed. The report now reads P4.regions[].damage_indicator and reports it honestly as a feature indicator, not a percentage of vehicle area. When P4 returns no contours, the report says analysis completed with no candidate regions instead of remaining on Waiting for analysis.

The old vehicle-3d.js and vehicle-3d.css files are no longer referenced. You may delete them after confirming the updated page works.

Run from PowerShell:
cd C:\Users\tanuj\Documents\AIM002_Member1_Starter_Implementation
.\.venv311\Scripts\Activate.ps1
python .\accident_damage_assessment\app.py

Then open http://127.0.0.1:5000 and press Ctrl+Shift+R.
