/* AutoInspect AI regional report: renders P4 contour regions from the analysis response. */
(() => {
  const root = document.getElementById("vehicle-region-report");
  if (!root || root.dataset.ready === "1") return;
  root.dataset.ready = "1";
  const $ = selector => root.querySelector(selector);
  const esc = value => String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[ch]));
  const clamp = value => Math.max(0, Math.min(1, Number(value) || 0));
  const levelFor = value => value >= 0.5 ? "High" : value >= 0.2 ? "Moderate" : "Low";
  const actionFor = level => level === "High"
    ? "Prioritise a qualified physical inspection before using the vehicle."
    : level === "Moderate"
      ? "Review this detected area closely and obtain a professional repair assessment."
      : "Document this candidate area and verify it against the original image.";

  function extract(payload) {
    const p4 = payload?.p4 ?? payload?.result?.p4 ?? payload?.data?.p4 ?? {};
    const regions = Array.isArray(p4.regions) ? p4.regions : [];
    return regions.map((region, index) => {
      const indicator = clamp(region.damage_indicator);
      const x = Number(region.x) || 0;
      const y = Number(region.y) || 0;
      const width = Number(region.width) || 0;
      const height = Number(region.height) || 0;
      const level = levelFor(indicator);
      return {
        name: `Detected region ${region.region_id ?? index + 1}`,
        indicator,
        level,
        description: `Candidate contour at image coordinates x=${x}, y=${y}, width=${width}, height=${height}. This is a feature-based indicator, not a verified vehicle-part classification.`,
        action: actionFor(level)
      };
    }).sort((a, b) => b.indicator - a.indicator);
  }

  function render(payload) {
    const p4 = payload?.p4 ?? payload?.result?.p4 ?? payload?.data?.p4 ?? {};
    const rows = extract(payload);
    const grid = $("[data-region-grid]");
    const status = $("[data-region-status]");
    const most = $("[data-most-affected]");
    const count = $("[data-region-count]");
    const highest = $("[data-highest-level]");
    const reportedCount = Number(p4.region_count);
    const regionCount = Number.isFinite(reportedCount) ? reportedCount : rows.length;
    const overallSeverity = String(p4.severity || "Not available");

    count.textContent = String(regionCount);
    highest.textContent = overallSeverity;

    if (!rows.length) {
      most.textContent = "No candidate region";
      status.textContent = "Analysis completed";
      grid.innerHTML = '<article class="aim-region-empty">The analysis completed successfully, but P4 did not identify any candidate damage contours in this image. This does not prove that the vehicle is damage-free.</article>';
      $("[data-next-steps]").innerHTML = [
        "Review the original image carefully in good lighting.",
        "If visible damage is present, try a clearer image showing the affected area.",
        "Arrange a physical inspection if the vehicle was involved in a collision."
      ].map(step => `<li>${esc(step)}</li>`).join("");
      return;
    }

    most.textContent = rows[0].name;
    status.textContent = "Analysis report updated";
    grid.innerHTML = rows.map((row, index) => `
      <article class="aim-region-card ${index === 0 ? "is-highest" : ""}">
        <div class="aim-region-card-top"><h3>${esc(row.name)}</h3><span class="aim-region-level ${row.level.toLowerCase()}">${row.level}</span></div>
        <div class="aim-region-score">${(row.indicator * 100).toFixed(1)}<small>% feature indicator (not damage area)</small></div>
        <div class="aim-region-track"><div class="aim-region-fill ${row.level.toLowerCase()}" style="width:${(row.indicator * 100).toFixed(1)}%"></div></div>
        <p>${esc(row.description)}</p>
        <div class="aim-region-action"><b>Recommended next step:</b> ${esc(row.action)}</div>
      </article>`).join("");

    const nextSteps = [
      `Priority 1 - ${rows[0].name}: ${rows[0].action}`,
      "Compare each candidate contour with the original uploaded image; the system does not identify exact vehicle parts.",
      "Confirm damage and repair decisions through a qualified physical inspection."
    ];
    $("[data-next-steps]").innerHTML = nextSteps.map(step => `<li>${esc(step)}</li>`).join("");
  }

  window.addEventListener("autoinspect:analysis-complete", event => render(event.detail || {}));
})();
