AutoInspect AI clean frontend update

Replace these files in your project:
index.html -> accident_damage_assessment\templates\index.html
style.css -> accident_damage_assessment\static\style.css
app.js -> accident_damage_assessment\static\app.js
region-report.js -> accident_damage_assessment\static\region-report.js

This version removes the complete Vehicle Inspection Studio section and all vehicle-3D script/style references. The hero is static. All interface sections use a light palette. Files are saved as UTF-8. The analysis API and P1-P4 backend are not modified.

After copying, restart Flask and hard-refresh the browser with Ctrl+Shift+R. The URL query version is also updated to reduce stale CSS/JS caching.
