(() => {
"use strict";
const $ = id => document.getElementById(id);
let selectedFile = null;
let objectUrl = null;

function showMessage(message, isError=false){
  const el=$("uploadMessage");
  if(el){el.textContent=message;el.style.color=isError?"#ff929b":"";}
}
function handleFile(file){
  if(!file) return;
  const allowed=["image/jpeg","image/png","image/bmp","image/webp"];
  if(!allowed.includes(file.type)){alert("Please choose a JPG, PNG, BMP, or WEBP image.");return;}
  if(file.size>25*1024*1024){alert("Image must be smaller than 25 MB.");return;}
  selectedFile=file;
  if(objectUrl) URL.revokeObjectURL(objectUrl);
  objectUrl=URL.createObjectURL(file);
  const preview=$("selectedImagePreview");
  preview.src=objectUrl; preview.style.display="block";
  $("fileName").textContent=file.name; $("fileName").classList.add("has-file");
  $("fileDetails").textContent=`${(file.size/1024/1024).toFixed(2)} MB · ${file.type}`;
  $("analyzeButton").disabled=false;
  $("uploadZone").classList.add("has-image");
  showMessage("Image ready for assessment.");
  document.body.classList.add("has-selected-image");
}
async function analyze(){
  if(!selectedFile){alert("Please select a vehicle image first.");return;}
  const btn=$("analyzeButton"); btn.disabled=true; btn.textContent="Analyzing…";
  $("analysisProgress").hidden=false;
  const phases=["Preparing image…","Enhancing image details…","Inspecting vehicle regions…","Estimating visible damage…","Building assessment report…"];
  let i=0; $("progressText").textContent=phases[0];
  const timer=setInterval(()=>{$("progressText").textContent=phases[++i%phases.length]},1200);
  try{
    const form=new FormData(); form.append("image",selectedFile);
    const response=await fetch("/api/analyze",{method:"POST",body:form});
    const result=await response.json();
    if(!response.ok||!result.success) throw new Error(result.error||`Analysis failed (HTTP ${response.status}).`);
    renderResults(result);
    showMessage("Assessment complete. Review the results below.");
    document.body.classList.add("analysis-complete");
  }catch(err){console.error(err);alert(err.message||"Image processing failed. Check the Flask terminal.");}
  finally{clearInterval(timer);$("analysisProgress").hidden=true;btn.disabled=!selectedFile;btn.innerHTML='<span class="button-icon">✦</span> Analyze Vehicle';}
}
function renderResults(result){
  const p4=result.p4||{}, severity=String(p4.severity||"Not available");
  const percent=Number(p4.damage_percent);
  const regions=Number(p4.region_count ?? (Array.isArray(p4.regions)?p4.regions.length:0));
  const score=p4.severity_score;
  $("resultsSection").hidden=false;
  $("resultSeverity").textContent=severity;
  $("resultDamage").textContent=Number.isFinite(percent)?`${percent.toFixed(2)}%`:"N/A";
  $("resultRegions").textContent=Number.isFinite(regions)?String(regions):"N/A";
  $("resultScore").textContent=score==null||!Number.isFinite(Number(score))?"N/A":Number(score).toFixed(3);
  $("resultOriginal").src=objectUrl;
  const artifacts=result.artifacts||{};
  $("resultVehicle").src=artifacts.vehicle||"";
  $("resultDamageImage").src=artifacts.candidate_mask||artifacts.damage_mask||"";
  $("resultEnhanced").src=artifacts.enhanced||"";
  const high=severity.toLowerCase().includes("high")||(Number.isFinite(percent)&&percent>=15);
  const moderate=severity.toLowerCase().includes("moderate")||(Number.isFinite(percent)&&percent>=5);
  const summary=high?"The image-based estimate indicates potentially substantial visible damage. Arrange a professional inspection promptly.":moderate?"The estimate suggests visible damage that may need repair. A physical inspection is recommended.":"The system estimates a lower visible damage level, but small or hidden damage may not be detected reliably.";
  $("resultSummary").textContent=summary;
  const actions=high?["Photograph affected areas from multiple angles.","Have a qualified repair professional inspect structural and safety-related components.","Avoid driving if steering, lights, wheels, airbags, or structural parts may be affected."]:moderate?["Capture close-up and wide-angle photographs.","Check nearby panels, lights, sensors, and alignment.","Request a repair estimate from a qualified workshop."]:["Inspect the vehicle in good lighting.","Check for hidden damage and functional issues.","Seek a professional opinion if the vehicle was involved in a collision."];
  $("resultActions").innerHTML=actions.map(x=>`<li>${x}</li>`).join("");
  $("resultsSection").scrollIntoView({behavior:"smooth",block:"start"});
}
document.addEventListener("DOMContentLoaded",()=>{
  const input=$("imageInput"), select=$("selectImageButton"), zone=$("uploadZone");
  select.addEventListener("click",e=>{e.preventDefault();input.click();});
  input.addEventListener("change",e=>handleFile(e.target.files?.[0]));
  zone.addEventListener("click",e=>{if(!e.target.closest("button"))input.click();});
  zone.addEventListener("dragover",e=>{e.preventDefault();zone.classList.add("dragging");});
  zone.addEventListener("dragleave",()=>zone.classList.remove("dragging"));
  zone.addEventListener("drop",e=>{e.preventDefault();zone.classList.remove("dragging");handleFile(e.dataTransfer.files?.[0]);});
  zone.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();input.click();}});
  $("analyzeButton").addEventListener("click",analyze);
});
})();