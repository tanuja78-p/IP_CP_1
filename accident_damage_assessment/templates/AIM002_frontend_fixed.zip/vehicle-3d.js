import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";
import { OrbitControls } from "https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/controls/OrbitControls.js";

const stage=document.getElementById("vehicle3dStage");
if(stage){
const loading=stage.querySelector(".vehicle-loading");
const label=stage.querySelector(".vehicle-camera-label");
const scene=new THREE.Scene();
scene.background=new THREE.Color(0x0a0f17);
const camera=new THREE.PerspectiveCamera(36,stage.clientWidth/stage.clientHeight,.1,100);
camera.position.set(5.8,3.4,6.8);
const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2)); renderer.setSize(stage.clientWidth,stage.clientHeight); renderer.outputColorSpace=THREE.SRGBColorSpace;
stage.appendChild(renderer.domElement);
const controls=new OrbitControls(camera,renderer.domElement); controls.enableDamping=true; controls.minDistance=4; controls.maxDistance=11; controls.target.set(0,1,0);
scene.add(new THREE.HemisphereLight(0xbfd7ff,0x182033,2.1));
const key=new THREE.DirectionalLight(0xffffff,3); key.position.set(4,7,5); scene.add(key);
const rim=new THREE.DirectionalLight(0x5d7dff,2); rim.position.set(-5,4,-4); scene.add(rim);
const floor=new THREE.Mesh(new THREE.CircleGeometry(7,64),new THREE.MeshStandardMaterial({color:0x0b111a,roughness:.9,metalness:.1}));
floor.rotation.x=-Math.PI/2; floor.position.y=-.03; scene.add(floor);
const grid=new THREE.GridHelper(12,24,0x263653,0x162238); grid.position.y=0; scene.add(grid);

const car=new THREE.Group(); car.position.y=.55; scene.add(car);
const bodyMat=new THREE.MeshPhysicalMaterial({color:0x365fd7,metalness:.72,roughness:.24,clearcoat:.8,clearcoatRoughness:.12});
const darkMat=new THREE.MeshStandardMaterial({color:0x10141b,metalness:.6,roughness:.3});
const glassMat=new THREE.MeshPhysicalMaterial({color:0x101d2c,metalness:.15,roughness:.08,transmission:.15,transparent:true,opacity:.92});
const lightMat=new THREE.MeshStandardMaterial({color:0xeef6ff,emissive:0x8fb8ff,emissiveIntensity:2});
const redMat=new THREE.MeshStandardMaterial({color:0xff3e48,emissive:0xff2028,emissiveIntensity:1.4});
function box(name,s,mat,p){const m=new THREE.Mesh(new THREE.BoxGeometry(...s),mat);m.name=name;m.position.set(...p);car.add(m);return m}
box("Lower body",[4.6,.62,1.9],bodyMat,[0,.65,0]);
box("Upper body",[3.9,.48,1.75],bodyMat,[.05,1.02,0]);
box("Hood",[1.45,.18,1.7],bodyMat,[1.35,1.3,0]);
box("Cabin",[2.15,.82,1.55],darkMat,[-.25,1.55,0]);
box("Windshield",[.08,.62,1.4],glassMat,[.88,1.58,0]);
box("Rear glass",[.08,.62,1.4],glassMat,[-1.38,1.58,0]);
box("Front bumper",[.25,.32,1.92],darkMat,[2.35,.63,0]);
box("Rear bumper",[.22,.3,1.9],darkMat,[-2.35,.62,0]);
box("Grille",[.12,.25,.9],darkMat,[2.48,.76,0]);
for(const z of [-.72,.72]){box("Headlight",[.1,.22,.38],lightMat,[2.5,.98,z]);box("Tail light",[.08,.2,.38],redMat,[-2.47,.96,z]);}
function wheel(x,z){const w=new THREE.Mesh(new THREE.CylinderGeometry(.48,.48,.28,32),darkMat);w.rotation.z=Math.PI/2;w.position.set(x,.45,z);car.add(w);const hub=new THREE.Mesh(new THREE.CylinderGeometry(.2,.2,.3,24),new THREE.MeshStandardMaterial({color:0x9aa5b8,metalness:.8,roughness:.25}));hub.rotation.z=Math.PI/2;hub.position.copy(w.position);car.add(hub)}
wheel(1.45,1.02);wheel(1.45,-1.02);wheel(-1.55,1.02);wheel(-1.55,-1.02);
for(const z of [-1.01,1.01]){box("Side skirt",[2.8,.12,.12],darkMat,[0,.48,z]);box("Mirror",[.28,.16,.18],darkMat,[.55,1.55,z*1.03]);}

const hotspots=[];
function hotspot(name,color,pos,view){const g=new THREE.Group();g.position.set(...pos);const mat=new THREE.MeshBasicMaterial({color,transparent:true,opacity:.95});const sphere=new THREE.Mesh(new THREE.SphereGeometry(.1,20,20),mat);g.add(sphere);const ring=new THREE.Mesh(new THREE.RingGeometry(.16,.21,32),new THREE.MeshBasicMaterial({color,transparent:true,opacity:.75,side:THREE.DoubleSide}));ring.rotation.x=-Math.PI/2;g.add(ring);g.userData={name,color,view};car.add(g);hotspots.push(g);return g}
hotspot("Front Bumper",0xff514f,[2.58,.82,0],"front");
hotspot("Front Right Fender",0xffb52e,[1.25,.88,1.02],"side");
hotspot("Headlight Area",0x4d9fff,[2.58,1.05,.72],"front");

const views={home:{p:[5.8,3.4,6.8],t:[0,1,0]},front:{p:[7,2.2,0],t:[0,.9,0]},side:{p:[0,2.5,8],t:[0,1,0]},rear:{p:[-7,2.2,0],t:[0,.9,0]},top:{p:[0,8,.01],t:[0,0,0]}};
function setView(name){const v=views[name]||views.home;camera.position.set(...v.p);controls.target.set(...v.t);controls.update();if(label)label.textContent=(name||"home").toUpperCase()+" VIEW";document.querySelectorAll("[data-view]").forEach(b=>b.classList.toggle("active",b.dataset.view===name))}
document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.view)));
let autoRotate=true;
const rotBtn=document.querySelector("[data-toggle-rotate]");
rotBtn?.addEventListener("click",()=>{autoRotate=!autoRotate;rotBtn.setAttribute("aria-pressed",String(autoRotate));rotBtn.classList.toggle("active",autoRotate)});
document.querySelectorAll("[data-damage-select]").forEach(btn=>btn.addEventListener("click",()=>{const title=btn.dataset.title,color=btn.dataset.color,view=btn.dataset.view;setView(view);const box=document.querySelector("[data-damage-detail]");box.innerHTML=`<div class="selected-area-filled"><h4 style="color:${color}">${title}</h4><p>${btn.dataset.body}</p></div>`;}));
const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
renderer.domElement.addEventListener("pointerdown",e=>{const r=renderer.domElement.getBoundingClientRect();pointer.x=((e.clientX-r.left)/r.width)*2-1;pointer.y=-((e.clientY-r.top)/r.height)*2+1;raycaster.setFromCamera(pointer,camera);const hit=raycaster.intersectObjects(hotspots.flatMap(h=>h.children),true)[0];if(hit){const h=hit.object.parent;document.querySelectorAll("[data-damage-select]").forEach(b=>{if(b.dataset.title===h.userData.name)b.click()})}});
const clock=new THREE.Clock();
function animate(){requestAnimationFrame(animate);const t=clock.getElapsedTime();if(autoRotate)car.rotation.y+=.0025;car.position.y=.55+Math.sin(t*1.2)*.018;hotspots.forEach((h,i)=>{const s=1+Math.sin(t*3+i)*.18;h.scale.setScalar(s)});controls.update();renderer.render(scene,camera)}
new ResizeObserver(()=>{const w=stage.clientWidth,h=stage.clientHeight;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h)}).observe(stage);
loading?.remove();animate();
}